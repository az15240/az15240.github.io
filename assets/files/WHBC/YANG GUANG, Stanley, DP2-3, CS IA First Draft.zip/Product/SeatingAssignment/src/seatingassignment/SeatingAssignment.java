/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seatingassignment;

import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Student-3
 */
public class SeatingAssignment {
    
    /**
     * Main class of the program
     * @param args the command line arguments
     * @throws FileNotFoundException
     * @throws Exception 
     */
    
    public static void main(String[] args) throws FileNotFoundException, Exception {
        
        Scanner scn=new Scanner(System.in);
        System.out.println("Welcome to the Seating Assignment Program, develoepd by Stanley!");
        
        Account myAcc=AccountManager.initAccount();
        if(myAcc==null) throw new Exception("Please login again.");
        System.out.println("Hi, "+AccountManager.currentAccount.getUsername());
        
        System.out.println("Options:\n1. create a new layout\n2. start assigning seats\n3. check features");
        
        int opt=scn.nextInt();
        if(opt==1) {
            Layout newLayout=new Layout(); 
            //a new layout is added to the account
        }
        else if(opt==2) {
            Scheme newScheme = new Scheme();
            newScheme.RandomSeating();//start assigning seats
        }
        else if(opt==3) {
            System.out.println("Current feature: random seating.\nOther features not implemented.");
        }
        else {
            throw new Exception("Invalid option!");
        }
    }
}
