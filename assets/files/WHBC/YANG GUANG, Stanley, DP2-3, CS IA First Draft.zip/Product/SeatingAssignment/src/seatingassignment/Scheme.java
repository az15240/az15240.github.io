/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seatingassignment;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Student-3
 */
public class Scheme {
    
    private String name;
    private Layout layout;
    private ArrayList<Student> students;
    private int numberOfStudents;
    private boolean[][] map;
    private String[][] mapNames;
    
    /**
     * Default constructor
     * Create a default scheme
     */
    public Scheme() {
        name="";
        layout=null;
        students=new ArrayList<Student>();
        numberOfStudents=-1;
        map=new boolean[0][0];
        mapNames=new String[0][0];
    }
    
    /**
     * Constructor
     * Create a normal scheme
     * @param _name name of the scheme
     * @param _layout layout of the scheme
     * @param _students List of students
     */
    public Scheme(String _name, Layout _layout, ArrayList<Student> _students) {
        name=_name;
        layout=_layout;
        students=_students;
        numberOfStudents=students.size();
        map=_layout.getMap();
        mapNames=new String[0][0];
    }
    
    /**
     * Accessor
     * Get the name of the scheme
     * @return name of the scheme
     */
    public String getName() {
        return name;
    }
    
    /**
     * Mutator
     * Set the name of the scheme to _name
     * @param _name name assigned
     */
    public void setName(String _name) {
        name=_name;
    }
    
    /** 
     * Accessor
     * Get the number of students in the scheme
     * @return number of students in the scheme
     */
    public int getNumberOfStudent() {
        return numberOfStudents;
    }
    
    /**
     * Accessor
     * Get the layout of the scheme
     * @return layout of the scheme
     */
    public Layout getLayout() {
        return layout;
    }
    
    /**
     * Mutator
     * Set the layout of the scheme to _layout
     * @param _layout layout value assigned
     */
    public void setLayout(Layout _layout) {
        layout=_layout;
    }
    
    /**
     * Accessor
     * Get the student list in the scheme
     * @return student list in the scheme
     */
    public ArrayList<Student> getStudentList() {
        return students;
    }
    
    /**
     * Mutator
     * Set the student list in the scheme to _students
     * @param _students student list assigned
     */
    public void setStudentList(ArrayList<Student> _students) {
        students=_students;
    }
    
    /**
     * Perform random seating on the scheme
     * @throws Exception 
     */
    public void RandomSeating() throws Exception {
        //initialize
        String username=AccountManager.currentAccount.getUsername();
        String thePath="Accounts/"+username+"/namelist.csv";
        Scanner fileReader = null;
        Scanner scn = new Scanner(System.in);
        int ok=1;
        
        //check if namelist.csv exists
        try {
            fileReader = new Scanner(new File(thePath));
        } catch(FileNotFoundException e) {
            ok=0;
            System.out.println("Input the namelist at "+thePath);            
        }
        if(ok==0) {
            System.out.println("Please input your namelist now, otherwise the program may crash! Input anything to continue assigning your seats.");
            File file1 = new File(thePath);
            file1.createNewFile();
            String emptyStr=scn.next();
        }
        
        //read in the student namelist
        fileReader = new Scanner(new File(thePath));
        while (fileReader.hasNext()) {
            String aName=fileReader.nextLine();
            //System.out.println("The student name is "+aName);
            students.add(new Student(aName));
        }
        fileReader.close();      
        
        //read the choice of layout
        System.out.println("Which layout do you want to use? Input the name of layout you want to use. The list of layouts is shown below:");
        String theName = null;
        String yourChoice = null;
        ArrayList<String> theNames = new ArrayList<String>();
        File folder = new File("Accounts/"+username+"/");
        File[] userFiles = folder.listFiles();
        for(File file : userFiles) {
            if(file.getName().contains(".txt")) {
                theName=file.getName().substring(0,file.getName().length()-4);
                theNames.add(theName);
                System.out.print(theName+", ");
            }
        }
        System.out.println("");
        scn=new Scanner(System.in);
        ok=0;
        while(ok==0) {
            yourChoice = scn.next();
            System.out.println("Your choice is: "+yourChoice);
            for(String aName:theNames) 
                if(yourChoice.equals(aName)) {
                    ok=1; 
                    break;
                }
            if(ok==0)
                System.out.println("This name not found! Input again!");
        }
        
        String pathName="Accounts/"+username+"/"+yourChoice+".txt";
        //System.out.println("The path is: "+pathName);
        layout=new Layout(new File(pathName));
        this.map=layout.map;
        this.numberOfStudents=layout.numSeats;
        
        if(students.size()!=numberOfStudents) {
            System.out.println("Student number = "+students.size());
            System.out.println("Number of seats = "+ layout.numSeats);
            throw new Exception("Number of student does not match!");
        }
        else {
            mapNames=new String[layout.ROWS+1][layout.COLUMNS+1];
            int OK=0,filled=0;
            //ArrayList<String> book=new ArrayList<String>();
            ArrayList<String> seats=new ArrayList<String>();
            HashMap<String,Pair> pos=new HashMap<String,Pair>();
            HashMap<String,Integer> book=new HashMap<String,Integer>();
            while(OK==0) {
                filled=0;
                book.clear();
                seats.clear();
                pos.clear();
                while(filled<numberOfStudents) {
                    int randm=(int)(Math.random()*numberOfStudents);
                    //System.out.print("randm="+randm+"\n");
                    if(book.get(students.get(randm).getName())==null) {
                        book.put(students.get(randm).getName(),1);
                        seats.add(students.get(randm).getName());
                        filled++;
                    }
                }
                System.out.println("Attempting:");
                int tempnum=0;
                for(int i=1;i<=layout.ROWS;i++) {
                    for(int j=1;j<=layout.COLUMNS;j++) {
                        if(map[i][j]) {
                            System.out.print(seats.get(tempnum)+", ");
                            mapNames[i][j]=seats.get(tempnum);
                            pos.put(seats.get(tempnum),new Pair(i,j));
                            tempnum++;
                        } 
                        else {
                            System.out.print("<empty>, ");
                            mapNames[i][j]="";
                        }
                    }
                    System.out.println();
                }
                
                File file1 = new File("Accounts/"+username+"/seating.csv");
                file1.createNewFile();
                
                try {
                    BufferedWriter writer = new BufferedWriter(new FileWriter(new File("Accounts/"+username+"/seating.csv")));
                    for(int i=1;i<=layout.ROWS;i++) {
                        for(int j=1;j<=layout.COLUMNS;j++) {
                            writer.write(mapNames[i][j] + ",");
                        }
                        writer.write("\n");
                        writer.flush();
                    }
                    writer.close();
                } catch (IOException ex) {
                    Logger.getLogger(SeatingAssignment.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                
                OK=1; // changed later when more requirements are added
            }
        }
    }
}
