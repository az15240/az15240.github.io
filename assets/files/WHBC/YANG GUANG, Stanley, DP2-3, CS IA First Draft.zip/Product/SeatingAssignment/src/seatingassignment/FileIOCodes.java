/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seatingassignment;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Student-3
 */
public class FileIOCodes {
    
    /**
     * Create a new directory
     * @param path path of the directory
     */
    public void CreateNewDirectory(String path) {
        File f1 = new File(path);  
        f1.mkdir();
    }
    
    /**
     * Create a new file
     * @param path path of the file
     * @throws IOException 
     */
    public void CreateNewFile(String path) throws IOException {
        File file1 = new File(path);
        file1.createNewFile();
    }
    
    /**
     * Read from a file
     * @throws FileNotFoundException 
     */
    public void FileInput() throws FileNotFoundException {
        try {
            Scanner fileReader = new Scanner(new File("Books.csv"));
            while(fileReader.hasNext()) {
                String[] nextBookInfo = fileReader.nextLine().split(",");
                System.out.println(nextBookInfo);
            }
            fileReader.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(SeatingAssignment.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /**
     * Read from a directory
     */
    public void FileInput2() {
        try {
            File folder = new File("path");
            File[] userFiles = folder.listFiles();
            for (File file : userFiles) {
                Scanner fileReader = new Scanner(file);
                while(fileReader.hasNext()) {fileReader.next();}
                fileReader.close();
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(SeatingAssignment.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /**
     * Output to a file
     * @throws IOException 
     */
    public void FileOutput() throws IOException {
        BufferedWriter writer = null;
        try {
            writer = new BufferedWriter(new FileWriter(new File("Books.csv")));
            writer.write("First, Second\n");
            writer.flush();
            writer.close();
        } catch (IOException ex) {
            Logger.getLogger(SeatingAssignment.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /**
     * Output to files in a directory
     */
    public void FileOutput2() {
        BufferedWriter writer = null;
        try {
            File folder = new File("users");
            File[] userFiles = folder.listFiles();
            for (File file : userFiles) {
                writer = new BufferedWriter(new FileWriter(file));
                writer.write("Some String\n");
                writer.write("First, Second\n");
                writer.newLine();
            }
            writer.close();
        } catch (IOException ex) {
            Logger.getLogger(SeatingAssignment.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
