/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seatingassignment;

/**
 *
 * @author Student-3
 */
public class Pair {
    
    private int x;
    private int y;
    private int num;
    
    /**
     * Constructor
     * Create a Pair object using x and y coordinates
     * @param _x x coordinate of the position
     * @param _y y coordinate of the position
     */
    public Pair(int _x, int _y) {
        x=_x;
        y=_y;
        num=pairToNum(_x,_y);
    }
    
    /**
     * Constructor
     * Create a Pair object using a single number as the position
     * @param _num single number position
     */
    public Pair(int _num) {
        num=_num;
        y=_num/Layout.COLUMNS+1;
        x=_num-(y-1)*Layout.COLUMNS; 
//        Pair _Pair=numToPair(_num);
//        x=_Pair.getX();
//        y=_Pair.getY();
    }
    
    /**
     * Convert an (x,y) pair to a single number
     * @param _x x coordinate of the position
     * @param _y y coordinate of the position
     * @return single number position
     */
    public int pairToNum(int _x, int _y) {
        return (_y-1)*Layout.COLUMNS+_x;
    }
    
    /*
    public Pair numToPair(int _num) {
        Pair _Pair=new Pair(_num);
        int _y=_num/Layout.COLUMNS+1;
        int _x=_num-(_y-1)*Layout.COLUMNS;
        _Pair.setX(_x);
        _Pair.setY(_y);
        return _Pair;
    }
    */
    
    /**
     * Accessor
     * Get the x coordinate of the pair
     * @return x coordinate of the pair
     */
    public int getX() {
        return x;
    }
    
    /**
     * Mutator
     * Set the x coordinate of the pair to _x
     * @param _x x coordinate assigned
     */
    public void setX(int _x) {
        x=_x;
    }
    
    /**
     * Accessor
     * Get the y coordinate of the pair
     * @return y coordinate of the pair
     */
    public int getY() {
        return y;
    }
    
    /**
     * Mutator
     * Set the y coordinate of the pair to _y
     * @param _y y coordinate assigned
     */
    public void setY(int _y) {
        y=_y;
    }
    
    /**
     * Accessor
     * Get the single number coordinate of the pair
     * @return single number coordinate of the pair
     */
    public int getNum() {
        return num;
    }
    
    /**
     * Mutator
     * Set the single number coordinate of the pair to _num
     * @param _num single number coordinate assigned
     */
    public void setNum(int _num) {
        num=_num;
    }
    
    /**
     * Overrides the toString method, return the String format of the pair
     * @return String format of the pair
     */
    @Override
    public String toString() {
        return "("+x+","+y+")";
    }
}
