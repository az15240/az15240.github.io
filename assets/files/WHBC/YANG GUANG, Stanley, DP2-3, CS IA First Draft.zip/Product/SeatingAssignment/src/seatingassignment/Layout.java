/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seatingassignment;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Student-3
 */
public class Layout {
    
    private String name;
    public static int ROWS;
    public static int COLUMNS;
    public static ArrayList<Pair> posCanceled;
    public static int numCanceled;
    public static int numSeats;
    public static boolean[][] map;
//    public static ArrayList<Integer> emptyColumns;  // not implemented
    
    /**
     * Default constructor
     * Evokes the initi method
     * @throws Exception 
     */
    public Layout() throws Exception {
        initi();
    }
    
    /**
     * Constructor
     * Construct a Layout object
     * @param _name name of the layout
     * @param _rows number of rows
     * @param _columns number of columns
     * @param _numCanceled number of positions to be canceled
     * @param _posCanceled positions canceled in the layout
     */
    public Layout(String _name, int _rows, int _columns, int _numCanceled, ArrayList<Pair> _posCanceled) {
        name=_name;
        ROWS=_rows;
        COLUMNS=_columns;
        posCanceled=_posCanceled;
        numCanceled=_posCanceled.size();
        numSeats=ROWS*COLUMNS-numCanceled;
        map=new boolean[ROWS+1][COLUMNS+1];
       
        for(int i=1;i<=ROWS;i++)
            for(int j=1;j<=COLUMNS;j++) {
                map[i][j]=true;
            }
        for(Pair pr:_posCanceled) {
            map[pr.getX()][pr.getY()]=false;
        }
    }
    
    /**
     * Constructor
     * Construct a Layout object by reading from a file
     * @param _file the Layout file
     * @throws FileNotFoundException 
     */
    public Layout(File _file) throws FileNotFoundException {
        System.out.println("The file name in \"Layout\" is "+_file.getName());
        Scanner scn=new Scanner(System.in);
        Scanner fileReader=new Scanner(_file);
        String fileName=_file.getName();
        name=fileName.substring(0,fileName.length()-4);
        //System.out.println("In Layout: name = "+name);
        ROWS=Integer.parseInt(fileReader.next());
        //System.out.println("In Layout: ROWS = "+ROWS);
        COLUMNS=Integer.parseInt(fileReader.next());
        //System.out.println("In Layout: COLUMNS = "+COLUMNS);
        numCanceled=Integer.parseInt(fileReader.next());
        //System.out.println("In Layout: numCanceled = "+numCanceled);
        numSeats=ROWS*COLUMNS-numCanceled;
        posCanceled=new ArrayList<Pair>();
        for(int i=0;i<numCanceled;i++) {
            String str=fileReader.next();
            int pos=str.indexOf(",");
            int _x=Integer.parseInt(str.substring(1,pos));
            int _y=Integer.parseInt(str.substring(pos+1,str.length()-1));
            Pair newPair=new Pair(_x,_y);
            posCanceled.add(newPair);
        }
        map=new boolean[ROWS+1][COLUMNS+1];
        for(int i=1;i<=ROWS;i++)
            for(int j=1;j<=COLUMNS;j++) {
                map[i][j]=true;
            }
        for(Pair pr:posCanceled) {
            map[pr.getX()][pr.getY()]=false;
        }
        
        scn.close();
        fileReader.close();
    }
    
    /**
     * Accesssor
     * Get the name of the layout
     * @return the name of the layout
     */
    public String getName() {
        return name;
    }
    
    /**
     * Mutator
     * Set the name to _name
     * @param _name name value assigned
     */
    public void setName(String _name) {
        name=_name;
    }
    
    /**
     * Accessor
     * Get the row number of the layout
     * @return row number of the layout
     */
    public int getRows() {
        return ROWS;
    }
    
    /**
     * Mutator
     * Set the row number of the layout to _rows
     * @param _rows row number assigned
     */
    public void setRows(int _rows) {
        ROWS=_rows;
    }
    
    /**
     * Accessor
     * Get the column number of the layout
     * @return column number of the layout
     */
    public int getColumns() {
        return COLUMNS;
    }
    
    /**
     * Mutator
     * Set the column number of the layout to _columns
     * @param _columns column number assigned
     */
    public void setColumns(int _columns) {
        COLUMNS=_columns;
    }
    
    /**
     * Accessor 
     * Get the number of seats in the layout
     * @return number of seats
     */
    public int getNumberOfSeats() {
        return numSeats;
    }
    
    /**
     * Mutator
     * Set the number of seats in the layout to _numSeats
     * @param _numSeats number of seats assigned
     */
    public void setNumberOfSeats(int _numSeats) {
        numSeats=_numSeats;
    }
    
    /**
     * Accessor
     * Get the positions of those canceled blocks
     * @return ArrayList of canceled positions
     */
    public ArrayList<Pair> getPosCanceled() {
        return posCanceled;
    }
    
    /**
     * Mutator
     * Set the canceled positions to _posCanceled
     * @param _posCanceled canceled positions assigned
     */
    public void setPosCanceled(ArrayList<Pair> _posCanceled) {
        posCanceled=_posCanceled;
    }
    
    /**
     * Accessor
     * Get the map display of the current layout
     * @return map display of the layout
     */
    public boolean[][] getMap() {
        return map;
    }
    
    /**
     * Initialize a layout by creating an Layout object from user input
     * @throws Exception 
     */
    public void initi() throws Exception {
        Scanner scn=new Scanner(System.in);
        System.out.println("init");
        System.out.println("Input the name of this new layout:");
        String _name=scn.next();
        System.out.println("Input rows:");
        int row=scn.nextInt();
        System.out.println("Input columns:");
        int col=scn.nextInt();
        System.out.println("Input number of blocks to cancel:");
        int cancelNum=scn.nextInt();
        System.out.println("You have selected "+cancelNum+" blocks to cancel. Input their coordinates in (<row>,<column>) format respectively.");
        ArrayList<Pair> _posCanceled=new ArrayList<Pair>();
        
        for(int i=1;i<=cancelNum;i++) {
            System.out.println("Number "+i+": ");
            int _x=scn.nextInt(), _y=scn.nextInt();
            _posCanceled.add(new Pair(_x,_y));
        }
        
        Layout myLayout=new Layout(_name,row,col,cancelNum,_posCanceled);
        System.out.println("Display the current map:");
        myLayout.displayMap();
        
        System.out.println("Are you satisfied with this layout? Press 1 if you like and the layout will be saved; press 0 to clear this entry to start a new layout. ");
        int opt=scn.nextInt();
        if(opt==1) {
            try {
                //write the configuration into a txt file
                String pathName = "Accounts/" + AccountManager.currentAccount.getUsername() + "/" + myLayout.name + ".txt";
                File file1 = new File(pathName);
                file1.createNewFile();
                BufferedWriter writer = new BufferedWriter(new FileWriter(pathName));
                //writer.write(myLayout.name + "\n");
                writer.write(myLayout.ROWS + "\n");
                writer.write(myLayout.COLUMNS + "\n");
                writer.write(myLayout.numCanceled + "\n");
                for(Pair pr:myLayout.posCanceled) 
                    writer.write(pr+"\n");
                writer.close();
            } catch (IOException ex) {
                Logger.getLogger(Layout.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println("Your layout named "+myLayout.name+" is successfully saved.");
        }
        else if(opt==0) {
            //restart the initialization process
            initi();
        }
        else {
            throw new Exception("Invalid option!");
        }
    }
    
    /**
     * Display the current map layout
     */
    public void displayMap() {
        for(int i=1;i<=ROWS;i++) {
            for(int j=1;j<=COLUMNS;j++) {
                if(map[i][j]==true) {
                    System.out.print("________ ");
                }
                else {
                    System.out.print("xxxxxxxx ");
                }
            }
            System.out.println();
        }
    }
}
