/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seatingassignment;

/**
 *
 * @author Student-3
 */
public class Student {
    
    private String name;
    private Pair position;
    private int notSeatWithNumber;
    
    /**
     * Constructor
     * Create a Student object with a name
     * @param _name name of the student
     */
    public Student(String _name) {
        name=_name;
    }
    
    /**
     * Constructor
     * Create a Student object with the name and the position
     * @param _name name of the student
     * @param _position position of the student
     */
    public Student(String _name, Pair _position) {
       name=_name;
       position=_position;
       notSeatWithNumber=-1;//default
    }
    
    /**
     * Constructor
     * Create a Student object with the name, the position, and its advanced property
     * Not actually implemented
     * @param _name name of the student
     * @param _position position of the student
     * @param _notSeatWithNumber advanced feature of the student
     */
    public Student(String _name, Pair _position, int _notSeatWithNumber) {
       name=_name;
       position=_position;
       notSeatWithNumber=_notSeatWithNumber;
    }
    
    /**
     * Accessor
     * Get the name of the student
     * @return name of the student
     */
    public String getName() {
        return name;
    }
    
    /**
     * Mutator
     * Set the name of the student to _name
     * @param _name name assigned
     */
    public void setName(String _name) {
        name=_name;
    }
    
    /**
     * Accessor
     * Get the position of the student
     * @return position of the student
     */
    public Pair getPos() {
        return position;
    }
    
    /**
     * Mutator
     * Set the position of the student to _pos
     * @param _pos position assigned
     */
    public void setPos(Pair _pos) {
        position=_pos;
    }
    
    /**
     * Accessor
     * Get the advanced feature of the student
     * @return advanced feature of the student
     */
    public int getNotSeatWithNumber() {
        return notSeatWithNumber;
    }
    
    /** 
     * Mutator
     * Set the advanced feature of the student
     * @param _notSeatWithNumber advanced feature assigned
     */
    public void setNotSeatWithNumber(int _notSeatWithNumber) {
        notSeatWithNumber=_notSeatWithNumber;
    }
}
